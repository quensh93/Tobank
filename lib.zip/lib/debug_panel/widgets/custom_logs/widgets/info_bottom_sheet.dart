import 'package:flutter/material.dart';
import 'package:ispect/ispect.dart';
import '../extensions/context.dart';
import '../utils/screen_size.dart';
import 'gap.dart';

class InfoBottomSheet extends StatefulWidget {
  const InfoBottomSheet({super.key});

  Future<void> show(BuildContext context) async {
    await context.screenSizeMaybeWhen(
      phone: () => showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        routeSettings: const RouteSettings(name: 'ISpect Logs Info Sheet'),
        builder: (_) => const InfoBottomSheet(),
      ),
      orElse: () => showDialog<void>(
        context: context,
        routeSettings: const RouteSettings(name: 'ISpect Logs Info Dialog'),
        builder: (_) => const InfoBottomSheet(),
      ),
    );
  }

  @override
  State<InfoBottomSheet> createState() => _InfoBottomSheetState();
}

class _InfoBottomSheetState extends State<InfoBottomSheet> {
  final _scrollController = ScrollController();

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => context.screenSizeMaybeWhen(
        phone: () => DraggableScrollableSheet(
          initialChildSize: 0.6,
          minChildSize: 0.3,
          maxChildSize: 0.9,
          expand: false,
          builder: (context, scrollController) => _Body(
            scrollController: scrollController,
          ),
        ),
        orElse: () => AlertDialog(
          contentPadding: EdgeInsets.zero,
          backgroundColor: context.ispectTheme.scaffoldBackgroundColor,
          content: SizedBox(
            height: MediaQuery.sizeOf(context).height * 0.7,
            width: MediaQuery.sizeOf(context).width * 0.8,
            child: _Body(
              scrollController: _scrollController,
            ),
          ),
        ),
      );
}

class _Body extends StatelessWidget {
  const _Body({
    required this.scrollController,
  });

  final ScrollController scrollController;

  @override
  Widget build(BuildContext context) {
    final theme = context.ispectTheme;
    return DecoratedBox(
      decoration: BoxDecoration(
        color: theme.scaffoldBackgroundColor,
        borderRadius: const BorderRadius.all(
          Radius.circular(16),
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: _InfoDescription(
            iSpect: ISpect.read(context),
            scrollController: scrollController,
          ),
        ),
      ),
    );
  }
}

class _InfoDescription extends StatelessWidget {
  const _InfoDescription({
    required this.iSpect,
    required this.scrollController,
  });

  final ISpectScopeModel iSpect;
  final ScrollController scrollController;

  @override
  Widget build(BuildContext context) {
    final logCategories = _getLogCategories(context, iSpect);

    return Column(
      children: [
        _Header(title: context.ispectL10n.iSpectifyLogsInfo),
        const Gap(16),
        Expanded(
          child: Scrollbar(
            controller: scrollController,
            interactive: true,
            thumbVisibility: true,
            child: ListView.separated(
              controller: scrollController,
              itemCount: logCategories.length,
              separatorBuilder: (_, __) => const Gap(16),
              itemBuilder: (context, index) {
                final category = logCategories.entries.elementAt(index);
                return _CategorySection(
                  title: category.key,
                  logs: category.value,
                  iSpect: iSpect,
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  Map<String, List<dynamic>> _getLogCategories(
    BuildContext context,
    ISpectScopeModel iSpect,
  ) {
    final dynamic descriptions = iSpect.theme
        .descriptions(context); // dynamic to bypass analysis mismatch
    final categories = <String, List<dynamic>>{};

    if (descriptions is Map) {
      for (final entry in descriptions.entries) {
        final category = _getCategory(entry.key, context);
        final log = {'key': entry.key, 'description': entry.value};
        categories.putIfAbsent(category, () => []).add(log);
      }
    } else if (descriptions is Iterable) {
      for (final dynamic entry in descriptions) {
        final entryMap = entry as Map<String, dynamic>;
        final category = _getCategory(entryMap['key'] as String, context);
        final log = {
          'key': entryMap['key'],
          'description': entryMap['description']
        };
        categories.putIfAbsent(category, () => []).add(log);
      }
    }

    return categories;
  }

  String _getCategory(String logKey, BuildContext context) {
    final l10n = context.ispectL10n;

    if (logKey.startsWith('http')) return l10n.iSpectifyTypeHttp;
    if (logKey.startsWith('bloc')) return l10n.iSpectifyTypeBloc;
    if (logKey.startsWith('riverpod')) return l10n.iSpectifyTypeRiverpod;

    return l10n.common;
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    final theme = context.ispectTheme;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style:
              theme.textTheme.headlineSmall?.copyWith(color: theme.textColor),
        ),
        IconButton(
          onPressed: () => Navigator.pop(context),
          visualDensity: VisualDensity.compact,
          icon: Icon(Icons.close_rounded, color: theme.textColor),
        ),
      ],
    );
  }
}

class _CategorySection extends StatelessWidget {
  const _CategorySection({
    required this.title,
    required this.logs,
    required this.iSpect,
  });

  final String title;
  final List<dynamic> logs;
  final ISpectScopeModel iSpect;

  @override
  Widget build(BuildContext context) {
    final theme = context.ispectTheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            color: theme.textColor,
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
        ),
        const Gap(8),
        ...logs.map((log) => _LogItem(log: log, iSpect: iSpect)),
      ],
    );
  }
}

class _LogItem extends StatelessWidget {
  const _LogItem({required this.log, required this.iSpect});

  final dynamic log;
  final ISpectScopeModel iSpect;

  @override
  Widget build(BuildContext context) {
    final theme = context.ispectTheme;
    final logMap = log as Map<String, dynamic>;
    final typeColor =
        iSpect.theme.getTypeColor(context, key: logMap['key'] as String);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: '${logMap['key']}: ',
              style: TextStyle(color: typeColor, fontWeight: FontWeight.w500),
            ),
            TextSpan(
              text: logMap['description'] as String,
              style: TextStyle(color: theme.textColor),
            ),
          ],
        ),
      ),
    );
  }
}
